WSHhell= new ActiveXObject("WScript.shell");
WSHhell.Run("calc.exe")
